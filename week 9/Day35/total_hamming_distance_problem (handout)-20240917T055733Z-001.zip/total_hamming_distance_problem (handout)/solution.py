def total_hamming_distance(nums):
    pass

if __name__ == "__main__":
    # Read input from the command prompt
    input_string = input()
    nums = list(map(int, input_string.split()))
    
    try:
        # Call the total_hamming_distance function and print the result
        result = total_hamming_distance(nums)
        print(result)
    except Exception as e:
        print(f"Error: {e}")
