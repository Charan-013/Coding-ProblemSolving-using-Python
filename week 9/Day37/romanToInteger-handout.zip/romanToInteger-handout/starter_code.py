
def roman_to_integer(s):
    # Write your code here
    pass
