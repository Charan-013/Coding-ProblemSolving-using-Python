def find_all_substrings(s):
    # Write your code here
    pass
