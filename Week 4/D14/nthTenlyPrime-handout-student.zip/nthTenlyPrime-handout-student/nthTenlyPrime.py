def nthTenlyPrime(n):
	return -1

print(nthTenlyPrime(int(input())))





	
