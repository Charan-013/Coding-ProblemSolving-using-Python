
def nthAdditivePrime(x):
	return 0

print(nthAdditivePrime(int(input())))
