def nthTidyNumber(n):
    return -1
print(nthTidyNumber(int(input())))





    
