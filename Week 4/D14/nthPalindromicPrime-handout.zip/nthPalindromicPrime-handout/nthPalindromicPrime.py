
def nthPalindromicPrime(x):
	return 0

print(nthPalindromicPrime(int(input())))