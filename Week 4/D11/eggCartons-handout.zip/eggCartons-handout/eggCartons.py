
def eggCartons(eggs):
	return 0

print(eggCartons(int(input())))