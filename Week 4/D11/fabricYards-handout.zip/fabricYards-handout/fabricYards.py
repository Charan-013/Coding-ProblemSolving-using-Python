
def fabricYards(inches):
	return 0

print(fabricYards(int(input())))