
def isLegalTriangle(s1, s2, s3):
	return True

print(isLegalTriangle(float(input()), float(input()), float(input())))