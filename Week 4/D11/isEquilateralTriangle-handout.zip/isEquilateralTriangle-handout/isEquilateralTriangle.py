
def isEquilateralTriangle(side1, side2, side3):
	return False

print(isEquilateralTriangle(float(input()), float(input()), float(input())))