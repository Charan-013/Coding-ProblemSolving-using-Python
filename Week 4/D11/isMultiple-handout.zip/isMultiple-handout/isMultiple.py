
def isMultiple(f, n):
	return False 

print(isMultiple(int(input()), int(input())))