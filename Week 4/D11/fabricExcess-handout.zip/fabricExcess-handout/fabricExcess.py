
def fabricExcess(inches):
	return 0

print(fabricExcess(int(input())))