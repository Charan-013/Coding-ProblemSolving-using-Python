# TASK 1

value_1_int = 1 
print("initial value_1=", value_1_int)
value_1_int = 2 
print("changed value_1=", value_1_int)

value_2_float = 1.1
print("initial value_2=", value_2_float)

value_2_float = 2.2 
print("changed value_2=", value_2_float)

value_3_string = "MS"
print("initial value_3=", value_3_string)
 
print("changed value_3=", value_3_string + "IT")

#swap
a1 = 0
b1 = 100
print("Before swap a =",a1, ", b =",b1)
a1, b1 = b1, a1
print("After swap a =",a1, ", b =",b1)