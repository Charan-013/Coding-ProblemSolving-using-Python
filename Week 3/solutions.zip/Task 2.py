# Task 2
var_integer = 1
var_float = 1.1
var_string = "MSIT"
var_boolean = True

print(type(var_integer), "Value =",var_integer)
print(type(var_float), "Value =",var_float)
print(type(var_string), "Value =",var_string)
print(type(var_boolean), "Value =",var_boolean)
print()
int_to_float = float(var_integer)
float_to_int = int(var_float)
float_to_string = str(var_float)
print("Integer to Float:", int_to_float)
print("Float to Integer:", float_to_int)
print("Float to String:", float_to_string)

