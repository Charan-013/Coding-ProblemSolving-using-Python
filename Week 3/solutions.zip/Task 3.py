var_integer = 1 # declaring int value 1 to var_integer. 
var_float = 1.1 # declaring float value 1.1 to var_float
var_string = "MSIT" #declaring string value MSIT to var_string
var_boolean = True #declaring boolean value true to var_string

print(var_integer) #printing value of var_integer
print(var_float) #printing value of value_float
print(var_string) #printing value of value_string
print(var_boolean) #printing value og var_boolean

print(var_integer1)
"""
output error:
Traceback (most recent call last):
  File "d:\MSIT\Python\Week 3\Task 3.py", line 11, in <module>
    print(var_integer1)
          ^^^^^^^^^^^^^^^^^
NameError: name 'var_integer1' is not defined.

The above error message is due to printing of undefined variable which is not initially declared in the program"""