print("MSIT"
# SyntaxError
# Explanation: this is because the print statement is missing a closing parenthesis so we are getting an error.

print(var)
# NameError
# Explanation: this is because the variable 'var' has not been defined or declared in the above code. and we are printing its value

int("MSIT")
# ValueError
# Explanation: Here string is declared insted of integer.

"string" + 5
#  TypeError
# Explanation: This error is because you cannot concatenate a string with an integer.Performing an invalid operation between incompatible data types

result = 5049 / 0
# ZeroDivisionError
# Explanation: this is because division by zero is not allowed in python programming.

import module
# ModuleNotFoundError:
# Explanation: this error is because we are trying to import a non-existent module in the installed python version
