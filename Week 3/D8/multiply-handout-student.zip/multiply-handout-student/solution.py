def mul(a,b):
    return a*b

a = float(input())
b = float(input())

print(mul(a,b))