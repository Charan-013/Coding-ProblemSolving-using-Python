
def rotateStringLeft(s, n):
	return ""
	

print(rotateStringLeft(input(), int(input())))
