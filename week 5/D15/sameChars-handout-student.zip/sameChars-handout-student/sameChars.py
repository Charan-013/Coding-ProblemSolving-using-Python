def sameChars(s1, s2):
	return True



print(sameChars(input(), input()))
