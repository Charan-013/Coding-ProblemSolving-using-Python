
def vowelCount(s):
	return -1

print(vowelCount(input()))