def replace(s1, s2, s3):
	return ""



print(replace(input(), input(), input()))
