def find_minimum(arr):
    pass

if __name__ == "__main__":
    # Read input from the command prompt
    input_string = input()
    arr = list(map(int, input_string.split()))
    
    try:
        # Call the find_minimum function and print the result
        result = find_minimum(arr)
        print(result)
    except Exception as e:
        print(f"Error: {e}")
