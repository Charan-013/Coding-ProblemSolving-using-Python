def readArray():
	a = []
	l = int(input())
	for i in range(l):
		a.append(int(input()))
	return a

def binaryListToDecimal(a):
	# your code goes here
	return 0
	
print(binaryListToDecimal(readArray()))


