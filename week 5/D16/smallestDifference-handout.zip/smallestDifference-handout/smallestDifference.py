def readArray():
    s = input().split(" ")
    l = []
    for i in s:
        if len(i) != 0:
            l.append(int(i))
    return l

def smallestDifference(a):
    # your code goes here
    return 0
    
print(smallestDifference(readArray()))


