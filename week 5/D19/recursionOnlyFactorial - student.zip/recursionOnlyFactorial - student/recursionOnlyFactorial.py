
def recursionOnlyFactorial(n):
	# your code goes here
	return 1

print(recursionOnlyFactorial(int(input())))


