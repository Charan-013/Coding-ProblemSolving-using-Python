

def recursionOnlyPowersof3ton(n):
	# your code goes here
	return -1


print(recursionOnlyPowersof3ton(float(input())))


