def readList():
	a = []
	l = int(input())
	for i in range(l):
		a.append(int(input()))
	return a

def recursionOnlyAlternatingSum(l):
	# your code goes here
	return -1

print(recursionOnlyAlternatingSum(readList()))


