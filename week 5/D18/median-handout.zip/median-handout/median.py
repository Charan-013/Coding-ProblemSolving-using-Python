def readArray():
	a = []
	l = int(input())
	for i in range(l):
		a.append(float(input()))
	return a

def median(a):
	# your code goes here
	return 0



print(median(readArray()))


